To run the program

--either create a c++ project in eclipse and use it

or use the following command line

g++ *.cpp -o output

